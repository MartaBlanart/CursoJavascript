$(document).ready(()=>{
    $("btn").click(() => {
        alert("click en el botón")
    })
})