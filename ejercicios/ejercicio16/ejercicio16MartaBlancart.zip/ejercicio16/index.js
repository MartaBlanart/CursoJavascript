let nombre="Marta"
let apellido= "Blancart"

let marta={nombre, apellido}

sessionStorage.setItem(nombre="marta", apellido="blancart")
localStorage.setItem(marta)
document.cookie="nombre=NuevaCookie"
//Falta saber como expira una cookie en 2 minutos

