//Creamos un set

const miFamilia= new Set ();

//Añadimos los elementos
miFamilia.add("Araceli");
miFamilia.add("Francisco Javier");
miFamilia.add("Javier");
miFamilia.add("Marta");

//Imprimimos

console.log(miFamilia);

//Añadimos nombre duplicado

miFamilia.add("Marta");

//Imprimimos

console.log(miFamilia);

//Añadimos elemento

miFamilia.add("Javascript");

//Imprimimos
console.log(miFamilia);
