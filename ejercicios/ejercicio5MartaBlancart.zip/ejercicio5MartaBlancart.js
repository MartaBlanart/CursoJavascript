let alturaCentimetros=160;
let alturaMetros=1.60;
let pesoKilos=60.3;
let alturaRedondeada= Math.ceil(alturaMetros);
console.log(alturaRedondeada);
let pesoRedondeado=Math.round(pesoKilos);
console.log(pesoRedondeado);
