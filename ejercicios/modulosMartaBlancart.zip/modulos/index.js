import {suma, multiplica} from "./modulos/controller.js"

const sum= (suma (4,5));