
const lista=new Array(4);

Array(0)="Marta";
Array(1)= 26;
Array(2)= true;
Array(3)= new Date (october, 9, 24);
Array (4)= libro={
    titulo: "Una noche más sin ti", 
    autor: "Sergio Pérez", 
    fecha: "24/10/21",
    url: "https://www.google.com/search?q=url+libro&oq=url+libro&aqs=chrome..69i57j0i512j0i15i22i30j0i22i30l5.3055j0j7&sourceid=chrome&ie=UTF-8",     

}


console.log(lista);
